import os

import jinja2

from latex import build_pdf

LATEX_JINJA_ENV = jinja2.Environment(
    block_start_string=r'\BLOCK{',
    block_end_string='}',
    variable_start_string=r'\VAR{',
    variable_end_string='}',
    comment_start_string=r'\#{',
    comment_end_string='}',
    line_statement_prefix='%%',
    line_comment_prefix='%#',
    trim_blocks=True,
    autoescape=False,
    loader=jinja2.FileSystemLoader(os.path.abspath('.'))
)
FOREST_TEMPLATE = LATEX_JINJA_ENV.get_template('forest_plot_template.tex')
FUNNEL_TEMPLATE = LATEX_JINJA_ENV.get_template('funnel_plot_template.tex')


def save_forest_plot(forest_data, folder) -> None:
    # file to save
    fname = os.path.join(folder, "forest_plot.tex")
    # render the template
    rendered = FOREST_TEMPLATE.render(data=(forest_data[:-1]
                                            .sort_values("study")
                                            .to_dict(orient='records')),
                                      ci_min=min(
                                      forest_data.ci_start.min(), 0) - 0.1,
                                      ci_max=max(
                                      forest_data.ci_end.max(), 0) + 0.1,
                                      **forest_data.iloc[-1].to_dict())

    # print .tex file
    with open(fname, "w") as f:
        print(rendered, file=f)
    # build pdf
    pdf = build_pdf(rendered)
    # save pdf
    fname = os.path.join(folder, "forest_plot.pdf")
    pdf.save_to(fname)


def save_funnel_plot(forest_data, folder) -> None:
    # file to save
    fname = os.path.join(folder, "funnel_plot.tex")
    # a little preprocessing
    slope = (forest_data.iloc[-1].ci_end - forest_data.iloc[-1].ci_start) / 2
    sigma_max = forest_data.sigma.max()
    es_min = forest_data.effect_size.min()
    es_max = forest_data.effect_size.max()
    effect_size = forest_data.iloc[-1].effect_size
    x_max = max(sigma_max / slope + effect_size, es_max)
    x_min = min(-sigma_max / slope + effect_size, es_min)
    # adding margin
    x_max += 0.05 * abs(x_max-x_min)
    x_min -= 0.05 * abs(x_max-x_min)
    # render the template
    rendered = FUNNEL_TEMPLATE.render(data=forest_data[:-1].to_dict(orient='records'),
                                      sigma_max=sigma_max,
                                      slope=slope,
                                      x_min=x_min,
                                      x_max=x_max,
                                      **forest_data.iloc[-1].to_dict())

    # print .tex file
    with open(fname, "w") as f:
        print(rendered, file=f)
    # build pdf
    pdf = build_pdf(rendered)
    # save pdf
    fname = os.path.join(folder, "funnel_plot.pdf")
    pdf.save_to(fname)


# def save_forest_plot(forest_data, folder, figsize=(4, 5)) -> None:
#     """Save a forest plot (png file and eps file) in the specified folder."""
#     # preprocessing
#     # put "overall_effect_size" in last position
#     mask = forest_data.study == "overall_effect_size"
#     overall_row_index = forest_data[mask].index[0]
#     idx = [overall_row_index] + forest_data[~mask].index.to_list()

#     forest_data = forest_data.loc[idx]
#     # half width of the confidence interval
#     half_width = forest_data.interval_end - forest_data.effect_size

#     # the forest plot
#     fig, ax = plt.subplots(figsize=figsize)
#     ax.errorbar(forest_data.effect_size,
#                 forest_data.study.apply(pretty_print_article_name),
#                 xerr=half_width,
#                 color="k",
#                 markersize=8,
#                 marker='s',
#                 fmt='o',
#                 capsize=5)

#     # vertical dashed line
#     ax.axvline(0, ls="--", lw=2, color="k")

#     # label fontsize
#     ax.set_xlabel("Effect size", fontsize=FONTSIZE)

#     # for the ticks
#     ax.tick_params(axis="x", direction="inout", length=8,
#                    width=3, color="k", labelsize=FONTSIZE)
#     ax.tick_params(axis="y", length=0, labelsize=FONTSIZE)

#     # Hide the right and top spines
#     ax.spines['right'].set_visible(False)
#     ax.spines['left'].set_visible(False)
#     ax.spines['top'].set_visible(False)

#     plt.tight_layout()
#     plt.savefig(os.path.join(folder, "forest_plot.png"),
#                 dpi=300, transparent=True)
#     plt.savefig(os.path.join(folder, "forest_plot.eps"),
#                 dpi=300, transparent=True)

#     plt.close(fig)


# def print_tables(forest_data, folder) -> None:
#     r"""
#     Save the data of the forest plot in tabular form (one text file and a latex
#     file) in the specified folder.

#     Example ouput: (table.txt)
#     ```
# Variable: AP Critical Displacement.
# Condition: prospective (2 studies).

#                Study  Number of subjects Effect size         95% CI Weight (%)
#            Kurz 2013                  98        0.97   [0.55, 1.39]       49.9
#             Hur 2009                 444        3.80   [3.48, 4.12]       50.1
#  Overall effect size                 542        2.39  [-0.39, 5.16]        100

# I² = 99.1% (random-effects model).
# Z-score (p-value): 1.7 (0.092).
#     ```

#     (table.tex)
#     ```
#     \begin{table}
#     \centering
#     \caption{
#         Variable: ap critical displacement.
#         Condition: prospective (2 studies).
#         I² = 99.1\% (random-effects model).
#         Z-score (p-value): 1.7 (9.2\%).
#         }
#     \begin{tabular}{lrlll}
#     \toprule
#     Study &  Number of subjects & Effect size &         95\% CI & Weight (\%) \\
#     \midrule
#     Kurz 2013 &              98 &        0.97 &   [0.55, 1.39] &       49.9 \\
#     Hur 2009 &             444 &        3.80 &   [3.48, 4.12] &       50.1 \\
#     Overall effect size & 542 &        2.39 &  [-0.39, 5.16] &        100 \\
#     \bottomrule
#     \end{tabular}
#     \end{table}
#     ```
#     """
#     # separate  the overall effect size row and the studies
#     overall_row = forest_data[forest_data.study ==
#                               'overall_effect_size'].iloc[0]
#     studies = forest_data[forest_data.study != 'overall_effect_size']
#     # formatting the information
#     formatted_studies = (pd.DataFrame(
#         {"Study": studies.study.apply(pretty_print_article_name),
#          "Condition": studies.conditions.apply(', '.join),
#          "Number of subjects": (studies.n_1+studies.n_2).astype(int),
#          "Effect size": studies.effect_size.map('{:.2f}'.format),
#          f"{100*(1-overall_row.alpha):.0f}% CI":
#          (studies[['interval_start', 'interval_end']]
#           .apply(lambda r: f"[{r.interval_start:.2f}, {r.interval_end:.2f}]",
#                  axis=1)),
#          "Weight (%)": (100*studies.weight/studies.weight.sum()).map(
#              '{:,.1f}'.format)})
#         .append({"Study": "Overall effect size",
#                  "Condition": ", ".join(overall_row.conditions),
#                  "Number of subjects": int(studies.n_1.sum()+studies.n_2.sum()),
#                  "Effect size": f"{overall_row.effect_size:.2f}",
#                  f"{100*(1-overall_row.alpha):.0f}% CI":
#                  f"[{overall_row.interval_start:.2f}, {overall_row.interval_end:.2f}]",
#                  "Weight (%)": 100}, ignore_index=True)
#     )

#     # print text file
#     plural = len(overall_row.conditions) > 1
#     msg = f"""Variable: {pretty_print_variable_name(overall_row.variable)}.
# {"Conditions" if plural else "Condition"}: {", ".join(overall_row.conditions)} ({forest_data.K.iloc[0]:.0f} studies).

# {formatted_studies.to_string(index=False, justify='right')}

# I² = {forest_data.I_square.iloc[0]*100:.1f}% ({forest_data.model.iloc[0]} model).
# Z-score (p-value): {overall_row.z_score:.1f} ({overall_row.p_value:.3f})."""

#     with open(os.path.join(folder, "table.txt"), "w") as my_file:
#         print(msg, file=my_file)

#     # print latex table
#     msg = f"""
#     Variable: {pretty_print_variable_name(overall_row.variable)}.
#     {"Conditions" if plural else "Condition"}: {", ".join(overall_row.conditions)} ({forest_data.K.iloc[0]:.0f} studies).
#     I² = {forest_data.I_square.iloc[0]*100:.1f}\\% ({forest_data.model.iloc[0]} model).
#     Z-score (p-value): {overall_row.z_score:.1f} ({overall_row.p_value:.3f}).
#     """
#     formatted_studies.to_latex(caption=msg, index=False,  buf=open(
#         os.path.join(folder, "table.tex"), "w"))
