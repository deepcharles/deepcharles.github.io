#!/usr/bin/env bash

set -e

venv=$1
input=$2
delta=$3

if [ ! -d "$venv" ]; then
  echo "Virtualenv not found" > demo_failure.txt
  exit 0
else
  source $venv/bin/activate
fi

echo python $bin/effect_size.py --input_fname $input --which_delta $delta --alpha 0.05
python $bin/effect_size.py --input_fname $input --which_delta $delta --alpha 0.05
tar czvf output.tar.gz output