from itertools import chain, combinations


def powerset(iterable):
    "powerset([1,2,3]) --> (1,) (2,) (3,) (1,2) (1,3) (2,3) (1,2,3)"
    s = list(iterable)
    ps = chain.from_iterable(combinations(s, r) for r in range(1, len(s)+1))
    return ps


def clean_str(a_str):
    """
    - remove leading and trailing spaces,
    - replace double spaces, tabs, line returns by underscore.
    """
    return " ".join(a_str.replace("_", " ").strip().split())
    # return "_".join(a_str.strip().lower().split())


def pretty_print_article_name(article_str):
    return article_str.capitalize().replace("_", " ").strip()


def pretty_print_variable_name(article_str):
    return article_str.replace("_", " ").strip()
