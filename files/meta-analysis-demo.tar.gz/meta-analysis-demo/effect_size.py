import os

import click
import numpy as np
import pandas as pd
from scipy.stats import norm
from sklearn.preprocessing import MultiLabelBinarizer

from plot import save_forest_plot, save_funnel_plot
from utils import clean_str, powerset

HEDGES = "Hedges"
COHEN = "Cohen"
FE_MODEL_STR = "fixed-effects"
RE_MODEL_STR = "random-effects"


def get_std_w_col(df):
    return np.sqrt(
        ((df.n_1-1)*df.std_1**2
         + (df.n_2-1)*df.std_2**2)
        / (df.n_1 + df.n_2 - 2))


def get_delta_d_col(df):
    """Cohen's d"""
    return (df.mean_1-df.mean_2) / df.std_w


def get_delta_g_col(df):
    """Hedges' g"""
    return (1-3/(4*(df.n_1+df.n_2)-9))*get_delta_d_col(df)


def get_std_intra_col(df):
    res = ((df.n_1+df.n_2)/df.n_1/df.n_2
           + df["effect_size"]**2/2/(df.n_1+df.n_2))
    return np.sqrt(res)


def get_w_fe_col(df):
    return 1/df.sigma**2


def get_mu_fe_val(df):
    weights = get_w_fe_col(df)
    weights /= weights.sum()
    return (weights*df.effect_size).sum()


def get_mu_val(df):
    weight_normalized = df.weight/df.weight.sum()
    return (weight_normalized*df.effect_size).sum()


def get_Q_val(df):
    return (df.w_fe*(df.effect_size-get_mu_fe_val(df))**2).sum()


def get_I_square_val(df):
    Q = get_Q_val(df)
    K = df.shape[0]
    return max((Q - (K - 1)) / Q, 0)


def get_model_val(I_square):
    if I_square < 0.5:
        return FE_MODEL_STR
    if I_square >= 0.5:
        return RE_MODEL_STR


def get_xi_val(df):
    w_sum = df.w_fe.sum()
    w_square_sum = (df.w_fe**2).sum()
    return w_sum - w_square_sum / w_sum


def get_tau_square_val(df):
    Q = get_Q_val(df)
    xi = get_xi_val(df)
    K = df.shape[0]
    return max((Q - (K - 1)) / xi, 0)


def get_w_re_col(df):
    tau_square = get_tau_square_val(df)
    return 1 / (df.sigma**2 + tau_square)


def get_overall_sigma_val(df):
    return 1 / np.sqrt(df.weight.sum())


def get_z_score_col(df):
    return df.effect_size / df.sigma


def get_p_value_col(df):
    return 2*(1-norm.cdf(abs(df.z_score)))


def get_ci_start_col(df, half_width):
    return df.effect_size-half_width*df.sigma


def get_ci_end_col(df, half_width):
    return df.effect_size+half_width*df.sigma


def load_data(input_fname, which_delta=HEDGES):
    """
    Load the data as a pandas dataframe. Also return the multilabel-binarizer
    used to encode the experimental conditions.
    """

    data = pd.read_csv(input_fname, sep=";",
                       converters={"study": clean_str,
                                   "feature": clean_str},
                                   dtype={"mean_1": np.float64, "std_1": np.float64, "mean_2": np.float64, "std_2": np.float64})

    keep_cols = ['study', 'mean_1', 'std_1', 'n_1',
                 'mean_2', 'std_2', 'n_2', 'variable']
    cond_cols = sorted(list(set(data.columns) - set(keep_cols)))

    # string cleaning
    data[cond_cols] = data[cond_cols].applymap(clean_str)

    # adding columns
    data = data.assign(
        std_w=get_std_w_col,
        effect_size=(get_delta_g_col if which_delta == HEDGES
                     else get_delta_d_col),
        sigma=get_std_intra_col,  # sigma_intra
        w_fe=get_w_fe_col)

    # encoding experimental conditions
    mlb = (MultiLabelBinarizer()
           .fit(data[cond_cols].apply(lambda x: x.to_list(), axis=1)))

    # one hot encode the experimental conditions
    conditions = pd.DataFrame(
        mlb.transform(data[cond_cols].apply(lambda x: x.to_list(), axis=1)),
        columns=mlb.classes_)

    data = pd.concat((data, conditions), axis=1).drop(cond_cols, axis=1)
    data["conditions"] = mlb.inverse_transform(
        data[mlb.classes_.tolist()].to_numpy())
    data["conditions"] = data["conditions"].apply(list)

    return data.sort_values("study", ascending=False), mlb


@click.command()
@click.option('--input_fname', help='Path to the input file.',
              type=click.Path(exists=True))
@click.option('--which_delta', type=str, default=HEDGES,
              help="Which effect size to use ('Cohen' or 'Hedges').")
@click.option('--alpha', default=0.05, type=float,
              help='Confidence level (usually, 0.05, i.e. 5%)')
def run_meta_analysis(input_fname, which_delta=HEDGES, alpha=0.05):

    # Print input_fname if the file exists.
    click.echo(click.format_filename(input_fname))
    # load data
    data, mlb = load_data(input_fname, which_delta=which_delta)
    # record all conditions
    all_conditions = mlb.classes_
    # half width of the confidence interval
    confidence_interval_half_width = norm.ppf(1-alpha*0.5)
    # loop over variables
    for variable, single_feat_df in data.groupby("variable"):
        print(variable, end=" / ", flush=True)

        max_val_dict = single_feat_df[all_conditions].max().to_dict()

        # find conditions that are present for this variable
        present_conditions = sorted(
            col for (col, max_val) in max_val_dict.items() if max_val == 1)
        # absent_conditions = sorted(col for (col, max_val) in max_val_dict.items() if max_val==0)

        # only need to go through present consitions
        ps = powerset(present_conditions)

        for sub_cond_cols in ps:
            query_str = " & ".join(f"`{col}`==1" for col in sub_cond_cols)
            single_feat_and_cond_df = single_feat_df.query(query_str)

            # two studies or more. If not, no computation.
            if single_feat_and_cond_df.shape[0] < 2:
                continue

            # Compute the overall effect size and store results in the
            # dictionary `d`.

            # d[var_name] = 0 if var_name never appears, 1 else.
            d = single_feat_and_cond_df[all_conditions].min().to_dict()

            d["study"] = "overall_effect_size"
            d["variable"] = variable
            d["I_square"] = get_I_square_val(single_feat_and_cond_df)
            d["K"] = single_feat_and_cond_df.shape[0]
            d["model"] = get_model_val(d["I_square"])
            d["conditions"] = sub_cond_cols
            K = single_feat_and_cond_df.shape[0]  # number of studies

            # add the weights to the original dataframe
            # the wieghts depend on the fixed- or random-effects model
            weight_func = (get_w_re_col if d["model"] == RE_MODEL_STR
                           else get_w_fe_col)

            single_feat_and_cond_df = (single_feat_and_cond_df
                                       .assign(weight=weight_func,
                                               model=d["model"],
                                               I_square=d["I_square"]))

            d["effect_size"] = get_mu_val(single_feat_and_cond_df)
            d["sigma"] = get_overall_sigma_val(single_feat_and_cond_df)
            single_feat_and_cond_df["weight"] = (
                single_feat_and_cond_df.weight /
                single_feat_and_cond_df.weight.sum() * 100)
            d["weight"] = single_feat_and_cond_df.weight.sum()

            # write results to output/
            folder = (
                f"{variable}-{'|'.join(col for col in present_conditions if d[col] == 1)}")
            folder = os.path.join("output", folder)
            os.makedirs(folder, exist_ok=True)

            fname = os.path.join(folder, "data.csv")
            df_to_write = (single_feat_and_cond_df
                           # add a row for the overall effect size
                           .append([d])
                           .assign(which_delta=which_delta, K=K,
                                   alpha=alpha, z_score=get_z_score_col, p_value=get_p_value_col,
                                   ci_start=lambda df: get_ci_start_col(
                                       df, confidence_interval_half_width),
                                   ci_end=lambda df: get_ci_end_col(df, confidence_interval_half_width))
                           [['study', 'variable',
                             'mean_1', 'std_1', 'n_1',
                             'mean_2', 'std_2', 'n_2',
                             'effect_size', 'sigma', 'which_delta',
                             'weight', 'conditions', "I_square", "model", "K",
                             "z_score", "p_value", "alpha", "ci_start", "ci_end"]]
                           )
            # a little formatting
            df_to_write["conditions"] = df_to_write.conditions.transform(
                ', '.join)
            # df_to_write["study"] = df_to_write.study.apply(
            #     pretty_print_article_name)
            df_to_write.to_csv(fname, index=False)
            save_forest_plot(df_to_write, folder)
            save_funnel_plot(df_to_write, folder)
            # print_tables(df_to_write, folder)
    print()


if __name__ == "__main__":
    run_meta_analysis()
