import os
import tarfile
from pathlib import Path
from urllib.request import urlretrieve

DATA_HOME = Path.cwd() / Path("FallData")
DOWNLOAD_URL = "https://plmbox.math.cnrs.fr/f/a05ad8fbe7674392962b/?dl=1"
ARCHIVE_FNAME = "FallData.tar.gz"


def download_data() -> None:
    """Download the data, extract them and remove the archive."""
    if DATA_HOME.exists():
        print(f"Data already exist ({DATA_HOME}).")
    else:
        print("Data are missing. Downloading them now...", end="", flush=True)
        urlretrieve(
            url=DOWNLOAD_URL,
            filename=ARCHIVE_FNAME,
            data=None,
            )

        print("Ok.")
        print("Extracting now...", end="", flush=True)
        tf = tarfile.open(ARCHIVE_FNAME)
        tf.extractall()
        print("Ok.")
        print("Removing the archive...", end="", flush=True)
        os.remove(ARCHIVE_FNAME)
        print("Ok.")


if __name__ == "__main__":
    download_data()
